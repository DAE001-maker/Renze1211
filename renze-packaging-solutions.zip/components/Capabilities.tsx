
import React from 'react';

const Capabilities: React.FC = () => {
  const features = [
    { title: "High-Capacity", desc: "Equipped for large-scale industrial orders with consistent quality.", icon: "⚡" },
    { title: "Eco-Focus", desc: "100% recyclable premium paper and non-toxic adhesives.", icon: "🌱" },
    { title: "Global Logistics", desc: "Factory-to-door shipping solutions that smooth your operations.", icon: "🌐" },
    { title: "Precision Design", desc: "Micrometer accuracy for perfectly fitting caps and seals.", icon: "🎯" },
  ];

  return (
    <section id="capabilities" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center gap-16">
          <div className="flex-1">
            <h2 className="text-3xl md:text-5xl font-bold mb-8 leading-tight">
              Direct. Seamless. <br/>
              <span className="text-[#008000]">High-Quality.</span>
            </h2>
            <p className="text-gray-600 text-lg mb-12">
              Renze stands as your solid, reliable factory partner. We bridge the gap between complex manufacturing and seamless door-to-door delivery. From high-volume food packaging to artisan handicrafts, our precision is your advantage.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              {features.map((f, idx) => (
                <div key={idx} className="flex gap-4">
                  <div className="text-3xl">{f.icon}</div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">{f.title}</h4>
                    <p className="text-sm text-gray-500">{f.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="flex-1 w-full">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=2070&auto=format&fit=crop" 
                alt="Production Line" 
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-8 left-8">
                <p className="text-white text-2xl font-bold">24/7 Operations</p>
                <p className="text-[#FFFF00] font-semibold">Reliability in every run</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Capabilities;
