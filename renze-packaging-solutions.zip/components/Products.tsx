
import React from 'react';

const products = [
  {
    title: "Eco-Friendly Round Boxes",
    description: "Sustainable solutions for high-end retail and gift packaging.",
    image: "https://picsum.photos/seed/box1/800/600",
  },
  {
    title: "Precision Industrial Tubes",
    description: "High-capacity production for electronics and hardware.",
    image: "https://picsum.photos/seed/tube1/800/600",
  },
  {
    title: "Food-Grade Tubes",
    description: "Perfectly sealed for tea, coffee, and dry gourmet snacks.",
    image: "https://picsum.photos/seed/food1/800/600",
  },
  {
    title: "Custom Luxury Tubes",
    description: "Bespoke finishing for handicrafts and premium electronics.",
    image: "https://picsum.photos/seed/luxury1/800/600",
  },
];

const Products: React.FC = () => {
  return (
    <section id="products" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Specialization</h2>
          <div className="w-20 h-1 bg-[#008000]"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((p, i) => (
            <div key={i} className="group cursor-pointer">
              <div className="relative overflow-hidden rounded-xl aspect-[3/4] mb-4">
                <img 
                  src={p.image} 
                  alt={p.title} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors"></div>
                <div className="absolute bottom-6 left-6 right-6 text-white transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                  <p className="text-sm font-semibold mb-2 opacity-0 group-hover:opacity-100 transition-opacity">CUSTOMIZABLE</p>
                  <button className="bg-white text-black px-4 py-2 rounded-full text-xs font-bold">VIEW DETAILS</button>
                </div>
              </div>
              <h3 className="text-xl font-bold mb-2">{p.title}</h3>
              <p className="text-gray-600 text-sm leading-relaxed">{p.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Products;
