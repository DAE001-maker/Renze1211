
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-950 text-white py-16">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="col-span-1 md:col-span-2">
          <div className="flex items-center gap-3 mb-6">
             <div className="w-10 h-10 rounded-full bg-[#FFFF00] flex items-center justify-center border-2 border-[#008000]">
                <span className="text-[#FF0000] font-bold text-xs">RENZE</span>
             </div>
             <span className="text-2xl font-bold tracking-widest">RENZE</span>
          </div>
          <p className="text-gray-400 max-w-sm mb-6">
            Dedicated to providing the world's finest round paper boxes and tubes through cutting-edge factory efficiency and direct logistics.
          </p>
          <div className="flex gap-4">
            {/* Social Icons Placeholder */}
            {[1,2,3,4].map(i => (
              <div key={i} className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 cursor-pointer transition-colors">
                <div className="w-4 h-4 bg-gray-400 rounded-sm"></div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h4 className="font-bold mb-6 uppercase tracking-widest text-sm">Industrial Units</h4>
          <ul className="space-y-4 text-gray-400 text-sm">
            <li><a href="#" className="hover:text-white transition-colors">Food & Agriculture</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Consumer Electronics</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Luxury Goods</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Logistics Solutions</a></li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold mb-6 uppercase tracking-widest text-sm">Contact Us</h4>
          <ul className="space-y-4 text-gray-400 text-sm">
            <li className="flex items-center gap-2">
               <span>📍</span> 888 Industrial Ave, Renze Park
            </li>
            <li className="flex items-center gap-2">
               <span>📞</span> +86 (555) 123-4567
            </li>
            <li className="flex items-center gap-2">
               <span>✉️</span> sales@renze-packaging.com
            </li>
          </ul>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 mt-16 pt-8 border-t border-white/10 text-center text-gray-500 text-xs">
        <p>© {new Date().getFullYear()} Renze Packaging Solutions. All Rights Reserved. Designed for Excellence.</p>
      </div>
    </footer>
  );
};

export default Footer;
