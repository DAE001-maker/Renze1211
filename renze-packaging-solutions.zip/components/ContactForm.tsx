
import React, { useState } from 'react';
import { InquiryData } from '../types';

const ContactForm: React.FC = () => {
  const [formData, setFormData] = useState<InquiryData>({
    name: '',
    email: '',
    company: '',
    industry: 'Other',
    quantity: '',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form Submitted:", formData);
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <section id="inquiry" className="py-24 bg-white">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Request a Consultation</h2>
          <p className="text-gray-500">Tell us about your project requirements and get a factory-direct quote.</p>
        </div>

        {submitted ? (
          <div className="bg-green-50 border border-green-200 text-green-700 p-8 rounded-2xl text-center animate-bounce">
            <h3 className="text-2xl font-bold mb-2">Inquiry Sent Successfully!</h3>
            <p>Our industrial specialists will contact you within 24 hours.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Full Name</label>
                <input 
                  required
                  type="text" 
                  className="bg-gray-50 border border-gray-200 p-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#008000] transition-all"
                  placeholder="John Doe"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                />
              </div>
              <div className="flex flex-col">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Work Email</label>
                <input 
                  required
                  type="email" 
                  className="bg-gray-50 border border-gray-200 p-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#008000] transition-all"
                  placeholder="john@company.com"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Company Name</label>
                <input 
                  required
                  type="text" 
                  className="bg-gray-50 border border-gray-200 p-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#008000] transition-all"
                  placeholder="Acme Inc."
                  value={formData.company}
                  onChange={(e) => setFormData({...formData, company: e.target.value})}
                />
              </div>
              <div className="flex flex-col">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Target Industry</label>
                <select 
                  className="bg-gray-50 border border-gray-200 p-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#008000] transition-all"
                  value={formData.industry}
                  onChange={(e) => setFormData({...formData, industry: e.target.value as any})}
                >
                  <option value="Food">Food & Beverage</option>
                  <option value="Electronics">Electronics</option>
                  <option value="Handicrafts">Handicrafts</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            <div className="flex flex-col">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Estimated Quantity</label>
              <input 
                required
                type="text" 
                className="bg-gray-50 border border-gray-200 p-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#008000] transition-all"
                placeholder="e.g. 50,000 units"
                value={formData.quantity}
                onChange={(e) => setFormData({...formData, quantity: e.target.value})}
              />
            </div>

            <div className="flex flex-col">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Message & Specs</label>
              <textarea 
                rows={4}
                className="bg-gray-50 border border-gray-200 p-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#008000] transition-all"
                placeholder="Dimensions, materials, finishing preferences..."
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
              ></textarea>
            </div>

            <button 
              type="submit" 
              className="w-full bg-[#008000] text-white py-4 rounded-lg font-bold text-lg hover:bg-[#006400] shadow-xl hover:shadow-2xl transform hover:-translate-y-1 transition-all duration-300"
            >
              SUBMIT INQUIRY
            </button>
          </form>
        )}
      </div>
    </section>
  );
};

export default ContactForm;
