
import React, { useState, useEffect } from 'react';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        {/* Logo Placeholder - Refers to the Renze Logo spirit */}
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 rounded-full bg-[#FFFF00] flex items-center justify-center border-2 border-[#008000] overflow-hidden">
            <span className="text-[#FF0000] font-bold text-xs">RENZE</span>
          </div>
          <span className={`text-xl font-bold tracking-widest ${isScrolled ? 'text-gray-900' : 'text-white'}`}>RENZE</span>
        </div>

        <nav className="hidden md:flex space-x-8 text-sm font-semibold tracking-wide">
          {['Products', 'Capabilities', 'Industries', 'Inquiry'].map((item) => (
            <a 
              key={item} 
              href={`#${item.toLowerCase()}`} 
              className={`hover:bg-black/5 px-4 py-2 rounded-md transition-colors ${isScrolled ? 'text-gray-800' : 'text-white'}`}
            >
              {item}
            </a>
          ))}
        </nav>

        <div>
          <a 
            href="#inquiry" 
            className="bg-[#008000] text-white px-6 py-2 rounded-full text-sm font-bold hover:bg-[#006400] transition-colors shadow-lg"
          >
            GET QUOTE
          </a>
        </div>
      </div>
    </header>
  );
};

export default Header;
