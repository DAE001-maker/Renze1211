
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative h-screen w-full flex items-center justify-center overflow-hidden">
      {/* Background Image - Simulated high-end industrial shot */}
      <img 
        src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?q=80&w=2070&auto=format&fit=crop" 
        alt="Industrial Factory" 
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="absolute inset-0 tesla-overlay"></div>

      <div className="relative z-10 text-center px-4 animate-fadeIn">
        <h1 className="text-white text-5xl md:text-7xl font-bold tracking-tight mb-4 drop-shadow-2xl">
          RENZE PACKAGING
        </h1>
        <p className="text-white text-lg md:text-2xl font-light mb-12 max-w-2xl mx-auto opacity-90">
          Premium Round Paper Boxes & Packaging Tubes. High-Capacity Manufacturing. Factory-to-Door Delivery.
        </p>
        
        <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
          <a 
            href="#products" 
            className="w-64 bg-white/10 backdrop-blur-md border border-white/30 text-white px-8 py-3 rounded-full font-bold hover:bg-white hover:text-black transition-all duration-300"
          >
            EXPLORE PRODUCTS
          </a>
          <a 
            href="#inquiry" 
            className="w-64 bg-[#008000] text-white px-8 py-3 rounded-full font-bold hover:bg-[#006400] transition-all duration-300 shadow-xl"
          >
            ORDER NOW
          </a>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  );
};

export default Hero;
