
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const SYSTEM_INSTRUCTION = `
You are the AI Assistant for Renze, a premium industrial factory specializing in round paper boxes and packaging tubes.
Your goal is to help potential clients understand Renze's capabilities:
1. We specialize in high-capacity production (food grade, electronics, handicrafts).
2. We offer direct factory-to-door packaging solutions and logistics.
3. Our products include: Round paper boxes, cardboard tubes, gift tubes, industrial shipping tubes.
4. Key industries: Food (tea, coffee, snacks), Electronics (gadgets), Cosmetics, Handicrafts.

When a user asks about sizes, explain that we offer fully custom diameters and heights.
Be professional, helpful, and concise (Tesla-style efficiency).
If they seem ready to order, suggest they fill out the inquiry form on the page.
Always maintain the persona of a reliable, high-end factory partner.
`;

export const getGeminiResponse = async (userPrompt: string, history: { role: 'user' | 'model', text: string }[]) => {
  try {
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    // In a real scenario, we might want to pass history. For now, we'll just send the message.
    const response = await chat.sendMessage({ message: userPrompt });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm sorry, I encountered an error. Please try again or use the contact form below.";
  }
};
